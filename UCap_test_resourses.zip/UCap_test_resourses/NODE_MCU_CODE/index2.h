const char webpage[] PROGMEM = R"=====(
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

    <!-- jQuery library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

    <!-- Popper JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

    <!-- Latest compiled JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

    <!-- fa fa icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <!-- font  -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Comfortaa:wght@700&display=swap" rel="stylesheet">
    <style>
        html {
            scroll-behavior: smooth;
        }

        .login-container {
            margin-top: 5%;
            margin-bottom: 5%;
        }

        .login-logo {
            position: relative;
            margin-left: -41.5%;
        }

        .login-logo img {
            position: absolute;
            width: 20%;
            margin-top: 19%;
            background: #282726;
            border-radius: 4.5rem;
            padding: 5%;
        }

        .ucap_left {
            padding: 9%;
            background: #282726;
            box-shadow: 0 5px 8px 0 rgba(0, 0, 0, 0.2), 0 9px 26px 0 rgba(0, 0, 0, 0.19);
        }

        .ucap_right {
            padding: 9%;
            box-shadow: 0 5px 8px 0 rgba(0, 0, 0, 0.2), 0 9px 26px 0 rgba(0, 0, 0, 0.19);
        }

        .login-form-1 {
            padding: 9%;
        }

        .bg-col-left {
            background: #282726;
            box-shadow: 0 5px 8px 0 rgba(0, 0, 0, 0.2), 0 9px 26px 0 rgba(0, 0, 0, 0.19);

        }

        .bg-col-right {
            box-shadow: 0 5px 8px 0 rgba(0, 0, 0, 0.2), 0 9px 26px 0 rgba(0, 0, 0, 0.19);
        }

        .login-form-1 h3 {
            text-align: center;
            margin-bottom: 12%;
            color: #fff;
        }

        .login-form-2 {
            padding: 9%;
        }

        .login-form-2 h3 {
            text-align: center;
            margin-bottom: 12%;
            /* color: #fff; */
        }

        .btnSubmit {
            font-weight: 600;
            width: 50%;
            color: #282726;
            background-color: #fff;
            border: none;
            border-radius: 1.5rem;
            padding: 2%;
        }


        /* my css */
        /* navbar */
        .navbar-brand h2 {
            font-family: 'Comfortaa', cursive;
        }

        .test {
            height: 100vh;
        }

        h2 {
            margin-bottom: 0;
        }

        .navigation-div {
            position: fixed;
            width: 100vw;
            z-index: 10;
        }


        /* tables */
        .collapsible-table {
            height: 200px;
            display: block;
            overflow-y: scroll;
        }
    </style>
</head>

<body class="bg-light">

    <!-- nav bar -->
    <div class="navigation-div">
        <nav class="navbar d-flex justify-content-between navbar-dark bg-dark">
            <div class="navbar-brand">
                <h2 class="text-white">Aartech</h2>
            </div>
        </nav>
    </div>


    <!-- test start here -->
    <div class="p-4">
        <div id="capacitor-test" class="test d-flex align-items-center capacitor-test">
            <div class="container login-container">
                <div class="row">
                    <div class="col-12 p-0">
                        <h2 class="bg-dark text-white text-center p-2">UCAP Test</h2>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6 ucap_left">
                        <h3>Test Parameters</h3>

                        <form>
                            <div class="form-group">
                                <input type="number" class="form-control" id="voltageinput" placeholder="Enter Maximum charging Voltage here">
                            </div>
                            <div class="form-group">
                                <input type="number" class="form-control" id="holdinput" placeholder="Enter Holding time  (in minutes)">
                            </div>
                            <div class="form-group">
                                <input type="number" class="form-control" id="NOT" placeholder="Enter No. of test to perform">
                            </div>
                            <div class="form-group">
                                <select class="form-control" id="bankinput">
                                    <option value="1">Bank1 ( 10 ohm )</option>
                                    <option value="2">Bank 1+2 ( 5 ohm )</option>
                                    <option value="3">NONE</option>
                                    <option value="4">NONE</option>
                                </select>
                            </div>


                            <a href="javascript:void(0)" onclick="sendData('ucap')" class=" btn btn-primary">Start Capacitance
                                Test
                            </a>

                            <div class="d-flex my-2 flex-wrap">
                                <a href="javascript:void(0)" onclick="manualTesting('charge')" class="btn  mr-1 btn-success">Charge</a>
                                <a href="javascript:void(0)" onclick="manualTesting('discharge')" class="btn mx-1 btn-warning">Discharge</a>
                                <a href="javascript:void(0)" onclick="manualTesting('stop')" class="btn btn-danger mx-1">Stop</a>
                            </div>
                        </form>
                    </div>
                    <div class="col-md-6 bg-light ucap_right">
                        <div class="login-logo">
                            <img src="https://image.ibb.co/n7oTvU/logo_white.png" alt="" />
                        </div>
                        <h3>Readings</h3>
                        <table class=" w-100 table-borderless ">
                            <tr>
                                <th>Voltage</th>
                                <td id="ucap_voltage">0</td>
                            </tr>
                            <tr>
                                <th>Current</th>
                                <td id="ucap_current">0</td>
                            </tr>
                            <tr>
                                <th>Status</th>
                                <td id="ucap_status">idle...</td>
                            </tr>
                            <tr>
                                <th>Charging time</th>
                                <td id="ucap_ct">0</td>
                            </tr>
                            <tr>
                                <th>Discharging time</th>
                                <td id="ucap_dt">0</td>
                            </tr>
                            <tr>
                                <th>No Of Test Done:</th>
                                <td id=""><Span id="ucap_TestNo"></Span>/<Span id="ucap_numberOfTest"></Span></td>
                            </tr>
                            <tr>
                                <th>Timer</th>
                                <td id="ucap_timer">0</td>
                            </tr>
                            <tr>
                                <th class="text-success">Capacitance</th>
                                <td id="ucap_capacitance">0</td>
                            </tr>
                        </table>
                        <div class="text-center pt-2">
                            <a class="btn btn-primary" data-toggle="collapse" href="#cap-list-tables" role="button" aria-expanded="false" aria-controls="cap-list-tables">
                                Capacitance - Test details <i class="fa fa-arrow-down" aria-hidden="true"></i>
                            </a>
                        </div>
                        <table class="collapse table w-100 fade collapsible-table" id="cap-list-tables">

                            <tr class="">
                                <th>Test no</th>
                                <th>Capacitance</th>
                            </tr>

                            <tbody id="cap-list-tables-body">
                                
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <!-- ESR / lc test -->
        <div id="esr-test" class="test d-flex align-items-center esr-test">
            <div class="container login-container">

                <div class="row">
                    <div class="col-md-6 bg-col-left">
                        <div class="w-100 mx-0">
                            <h2 class="bg-light text-dark text-center p-2">ESR Test</h2>
                        </div>
                        <!-- ESR here -->
                        <div class="login-form-1">
                            <a href="javascript:void(0)" onclick="sendData('esr')" class="my-2 btn-primary btn">Start ESR
                                Test
                            </a>
                            <h4 class="text-white">Status : <span id="esr_status" class="text-success"> pending..</span></h4>
                        </div>
                    </div>
                    <div class="col-md-6 bg-col-right">
                        <div class="w-100 mx-0">
                            <h2 class="bg-dark text-white text-center p-2">Life Cycle Test</h2>
                        </div>
                        <!-- ESR here -->
                        <div class="login-form-2">
                            <div class="form-group">
                                <input type="number" class="form-control" id="no_of_cycles" placeholder="Enter No. of cycles to perform">
                            </div>
                            <a href="javascript:void(0)" onclick="sendData('lc')" class="my-2 btn-primary btn">Start LifeCycle
                                Test
                            </a>
                            <a class="btn btn-success" data-toggle="collapse" href="#lc-tables" role="button" aria-expanded="false" aria-controls="lc-tables">
                                Show completed/ongoing Results <i class="fa fa-arrow-down" aria-hidden="true"></i>
                            </a>
                            <table class="collapse w-100 fade collapsible-table" id="lc-tables">
                                <thead>
                                    <th>Cycle no</th>
                                    <th>Result</th>
                                    </tr>
                                </thead>
                                <tbody id="lc-tables-body">
                                    <tr>
                                        <td>1</td>
                                        <td>45</td>
                                    </tr>
                                </tbody>

                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>



</body>



<script>

    //  sending manual tesing data  -------------
    function manualTesting(btn) {
        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function () {
            if (this.readyState == 4 && this.status == 200) {
                console.log("request completed data");
                getData();
            }
            console.log("in manual testing funtiion");
        };
        var url = "/manual_test?action=" + btn;
        xhttp.open("GET", url, true);
        xhttp.send();
    }

    function sendData(test_type) {
        console.log("in senddata");
        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function () {
          
            if (this.readyState == 4 && this.status == 200) {
                console.log("request completed data");
                getData();
            }
            console.log("in rs");
        };
        if (test_type == 'ucap') {
            var v = document.getElementById("voltageinput").value;
            var h = document.getElementById("holdinput").value;
            var b = document.getElementById("bankinput").value;
            var No = document.getElementById("NOT").value;
            console.log("got input data");
            var url = "/send_data?test_type=ucap&max_voltage=" + v + "&hold_time=" + h + "&select_bank=" + b + "&NOT=" + No;
        }
        else if (test_type == 'esr') {
            var url = "/send_data?test_type=esr";
        }
        else if (test_type == 'lc') {
            var NOC = document.getElementById("no_of_cycles").value;
            var url = "/send_data?test_type=lc&NOC=" + NOC;
        }
        xhttp.open("GET", url, true);
        xhttp.send();

    }
    setInterval(function () {
        getData();
    }, 2000);

    function getData() {
        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function () {
            if (this.readyState == 4 && this.status == 200) {
                console.log(this.responseText);
                var names = this.responseText;
                var nameArr = names.split(',');
                var test_type = nameArr[0]

                if (test_type == 'ucap') {

                    var no_of_test = nameArr[1];

                    var cap_table = document.getElementById("cap-list-tables-body");
                    cap_table.innerHTML = "";
                    for (let i = 2; i < 2+ parseInt(no_of_test); i++) {
                        cap_table.innerHTML += `<tr>  <td>${i - 1}</td>
                                    <td>${ nameArr[i]}</td></tr>`;
                    }
                    var after_i = 1+parseInt(no_of_test);
                    document.getElementById("ucap_numberOfTest").innerHTML = no_of_test;
                    document.getElementById("ucap_TestNo").innerHTML = nameArr[after_i + 1];
                    document.getElementById("ucap_voltage").innerHTML = nameArr[after_i + 2];
                    if (nameArr[after_i + 3] == "0") {
                        document.getElementById("ucap_status").innerHTML = "Idle";
                    }
                    else if (nameArr[after_i + 3] == "1") {
                        document.getElementById("ucap_status").innerHTML = "Charging...";
                    }
                    else if (nameArr[after_i + 3] == "2") {
                        document.getElementById("ucap_status").innerHTML = "DisCharge.";
                    }
                    else if (nameArr[after_i + 3] == "4") {
                        document.getElementById("ucap_status").innerHTML = "HOLD";
                    }
                    document.getElementById("ucap_current").innerHTML = nameArr[after_i + 4];
                    document.getElementById("ucap_ct").innerHTML = nameArr[after_i + 5];
                    document.getElementById("ucap_timer").innerHTML = nameArr[after_i + 6];
                    document.getElementById("ucap_capacitance").innerHTML = nameArr[after_i + 7];
                    document.getElementById("ucap_dt").innerHTML = nameArr[after_i + 8];
                }
                else if (test_type == 'esr') {
                    document.getElementById("esr_status") = nameArr[1];
                }
                else if (test_type == 'lc') {
                    var no_of_cycle = nameArr[1]
                    var lc_table = document.getElementById("lc-tables-body");
                    lc_table.innerHTML = "";
                    for (let i = 2; i <= parseInt(no_of_cycle); i++) {
                        lc_table.innerHTML += `<tr>  <td>${i - 1}</td><td>${nameArr[i]}</td></tr>`;
                    }
                }


            }
        };
        xhttp.open("GET", "/getdata", true);
        xhttp.send();

    }
</script>

</html>
)=====";
